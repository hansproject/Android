package com.example.hp.activitypractice;

public class Move {

    public int score;
    public int position;

// Constructor. Initial score is 0 which means no move has been done yet
//_________________________________________________________________
    public Move(){ score = 0; }

}
